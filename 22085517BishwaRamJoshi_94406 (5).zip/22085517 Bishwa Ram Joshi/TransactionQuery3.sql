SQL> SELECT V.Vendor_ID, V.Vendor_Name, V.Vendor_ContactInfo
  2  FROM Vendor V
  3  JOIN Product P ON V.Vendor_ID = P.Vendor_ID
  4  GROUP BY V.Vendor_ID, V.Vendor_Name, V.Vendor_ContactInfo
  5  HAVING COUNT(P.Product_ID) > 3;

 VENDOR_ID VENDOR_NAME          VENDOR_CONTACTINFO                              
---------- -------------------- --------------------                            
       407 Electronics Plus     +977-456-789-0123                               

SQL> spool off
