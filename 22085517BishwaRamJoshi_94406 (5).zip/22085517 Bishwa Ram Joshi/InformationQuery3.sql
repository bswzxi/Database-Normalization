SQL> SELECT Customer.Customer_ID, Customer.Customer_Name, Orders.Order_ID, Orders.Order_Date
  2  FROM Customer
  3  JOIN Customer_Order_Product ON Customer.Customer_ID = Customer_Order_Product.Customer_ID
  4  JOIN Orders ON Customer_Order_Product.Order_ID = Orders.Order_ID
  5  ;

CUSTOMER_ID CUSTOMER_NAME          ORDER_ID ORDER_DAT                           
----------- -------------------- ---------- ---------                           
          1 Rajesh Shrestha             101 10-MAY-23                           
          2 Sarita Thapa                102 14-MAY-23                           
          3 Mohan Pokharel              103 15-JUL-23                           
          4 Anita Pariyar               104 16-AUG-23                           
          5 Binod Shahi                 105 17-SEP-23                           
          6 Sujan Rai                   106 18-SEP-23                           
          7 Nirmala Gurung              107 19-OCT-23                           

7 rows selected.

SQL> spool off
