SQL> SELECT Customer.Customer_ID, Customer.Customer_Name, Orders.Order_Date, Orders.Order_Quantity, Orders.Order_Total AS TotalExpenses
  2  FROM Orders
  3  JOIN Customer_Order_Product
  4  ON Orders.Order_ID = Customer_Order_Product.Order_ID
  5  JOIN Customer
  6  ON Customer.Customer_ID = Customer_Order_Product.Customer_ID
  7  WHERE Orders.Order_Date BETWEEN TO_DATE('2023-08-01', 'YYYY-MM-DD') AND TO_DATE('2023-08-31', 'YYYY-MM-DD');

CUSTOMER_ID CUSTOMER_NAME        ORDER_DAT ORDER_QUANTITY TOTALEXPENSES         
----------- -------------------- --------- -------------- -------------         
          4 Anita Pariyar        16-AUG-23              2          90.5         

SQL> spool off
