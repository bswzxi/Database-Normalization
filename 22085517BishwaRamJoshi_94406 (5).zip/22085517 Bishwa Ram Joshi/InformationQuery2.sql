SQL> SELECT * FROM Orders WHERE Order_Date BETWEEN TO_DATE('2023-05-01', 'YYYY-MM-DD') AND TO_DATE('2023-05-28', 'YYYY-MM-DD');

  ORDER_ID ORDER_DAT ORDER_TOTAL ORDER_QUANTITY INVOICE_ID                      
---------- --------- ----------- -------------- ----------                      
       101 10-MAY-23         150              2        301                      
       102 14-MAY-23        75.5              1        302                      

SQL> spool off
