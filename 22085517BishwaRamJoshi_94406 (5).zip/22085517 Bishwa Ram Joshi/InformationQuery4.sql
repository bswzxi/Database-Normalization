SQL> SELECT * FROM Product WHERE SUBSTR(Product_Name, 2, 1) = 'a' AND Product_Stock > 50;

PRODUCT_ID PRODUCT_NAME         PRODUCT_DESC                                    
---------- -------------------- ----------------------------------------        
CATEGORY_ID PRODUCT_PRICE PRODUCT_STOCK  VENDOR_ID                              
----------- ------------- ------------- ----------                              
       209 Camera DSLR          Professional camera                             
          6       1499.99            55        407                              
                                                                                
       210 Camera DSLR          Professional camera                             
          6       1499.99            55        407                              
                                                                                

SQL> spool off
