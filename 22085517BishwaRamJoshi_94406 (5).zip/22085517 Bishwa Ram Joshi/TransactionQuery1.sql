SQL> SELECT TO_CHAR(O.Order_Date, 'YYYY-MM') AS Month, SUM(O.Order_Total) AS Total_Revenue
  2  FROM Orders O
  3  GROUP BY TO_CHAR(O.Order_Date, 'YYYY-MM');

MONTH   TOTAL_REVENUE                                                           
------- -------------                                                           
2023-07           120                                                           
2023-10          80.2                                                           
2023-05         225.5                                                           
2023-09        245.75                                                           
2023-08          90.5                                                           

SQL> spool off
