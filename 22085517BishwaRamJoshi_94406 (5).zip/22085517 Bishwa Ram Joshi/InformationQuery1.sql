SQL> SELECT * FROM Customer WHERE Customer_Category IN ('S');

CUSTOMER_ID CUSTOMER_NAME        CUSTOMER_ADDRESS     C CONTACT_NUMBER          
----------- -------------------- -------------------- - ---------------         
          2 Sarita Thapa         Pokhara              S +977-9854321098         
          5 Binod Shahi          Biratnagar           S +977-9854321098         

SQL> spool off;
