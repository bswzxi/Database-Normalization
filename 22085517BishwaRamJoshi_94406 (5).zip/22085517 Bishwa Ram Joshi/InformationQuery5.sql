SQL> SELECT *
  2  FROM (
  3  SELECT C.Customer_ID, C.Customer_Name, O.Order_Date
  4  FROM Customer C
  5  JOIN Customer_Order_Product COP ON C.Customer_ID = COP.Customer_ID
  6  JOIN Orders O ON COP.Order_ID = O.Order_ID
  7  ORDER BY O.Order_Date DESC
  8  )
  9  WHERE ROWNUM = 1;

CUSTOMER_ID CUSTOMER_NAME        ORDER_DAT                                      
----------- -------------------- ---------                                      
          7 Nirmala Gurung       19-OCT-23                                      

SQL> spool off
