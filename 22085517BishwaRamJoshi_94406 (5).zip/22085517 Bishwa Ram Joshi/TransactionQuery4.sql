SQL> SELECT *
  2  FROM (
  3      SELECT
  4          P.Product_ID,
  5          P.Product_Name,
  6          P.Product_Desc,
  7          COUNT(COP.Product_ID) AS TotalOrders
  8      FROM
  9          Product P
 10      JOIN
 11          Customer_Order_Product COP ON P.Product_ID = COP.Product_ID
 12      GROUP BY
 13          P.Product_ID, P.Product_Name, P.Product_Desc
 14      ORDER BY
 15          TotalOrders DESC
 16  )
 17  WHERE ROWNUM <= 3;

PRODUCT_ID PRODUCT_NAME         PRODUCT_DESC                                    
---------- -------------------- ----------------------------------------        
TOTALORDERS                                                                     
-----------                                                                     
       203 Tablet A             High-end tablet                                 
          1                                                                     
                                                                                
       201 Smartphone X         High-end smartphone                             
          1                                                                     
                                                                                
       202 Laptop Pro           Powerful laptop                                 
          1                                                                     
                                                                                

SQL> spool off
