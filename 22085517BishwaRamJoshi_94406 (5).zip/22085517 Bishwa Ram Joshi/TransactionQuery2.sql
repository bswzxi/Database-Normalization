SQL> SELECT * FROM Orders WHERE Order_Total >= (SELECT AVG(Order_Total) FROM Orders);

  ORDER_ID ORDER_DAT ORDER_TOTAL ORDER_QUANTITY INVOICE_ID                      
---------- --------- ----------- -------------- ----------                      
       103 15-JUL-23         120              3        303                      
       105 17-SEP-23         200              4        305                      
       101 10-MAY-23         150              2        301                      

SQL> spool off
